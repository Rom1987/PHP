<?php
$link = mysqli_connect("localhost","root","","sklad");
mysqli_query($link, "SET NAMES 'utf-8'");