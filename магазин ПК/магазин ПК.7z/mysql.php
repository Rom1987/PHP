<?php
$link = mysqli_connect("localhost", "root", "", "computer_shop");
mysqli_query($link, "SET NAMES 'utf-8'");
